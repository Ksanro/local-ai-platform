"""Symbol graph tests."""
