"""Gateway core modules."""


